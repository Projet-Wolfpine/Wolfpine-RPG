#define Y 16
#define X 30
void start();
void map();
void lecture_fichier_map(char nom_fichier[20],int map_int[Y][X]);