#include "menu_principal.h"
#include "fonction_sdl.h"
#include "deplacement.h"

int main(int argc, char** argv){
	init_affichage();
    Menu();
    return 0;
}
