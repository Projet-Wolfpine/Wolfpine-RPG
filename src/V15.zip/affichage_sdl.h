int afficher_menu(char menu[4][30]);
