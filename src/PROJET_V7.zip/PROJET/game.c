#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "fonction_sdl.h"
#include "gestion_deplacement_sdl.h"
#include "menu_principal.h"
#include "deplacement.h"
#include "game.h"
#include "creation_map.h"

#define TAILLE_CASE_PXL 32

void lecture_fichier_map(char nom_fichier[20],int map_int[Y][X]){
  /* lis un fichier.txt data de a map demandée,
   et met chaque entier dans une case de la matrice*/
  int i, j, var;
  FILE * fic;
  fic=fopen(nom_fichier,"r");
  fscanf(fic,"%i", &var);
  for(i=0;i<Y;i++){
    for(j=0;j<X;j++){
      map_int[i][j]=var;
      fscanf(fic,"%i", &var);
    }
  }
  fclose(fic);
}

perso_t *joueur;
//joueur = malloc(sizeof(perso_t));


void map(){
	//fond_blanc();
    
	int longeur = 1920;
	int hauteur = 1080;
	int longeur_mat = longeur/TAILLE_CASE_PXL;
	int hauteur_mat = hauteur/TAILLE_CASE_PXL;
	/*for(int i = 0;i<longeur_mat; i++) // i coresppond a x de la matrice et j coresppond a y en ordonnée 
			for(int j = 0; j<hauteur_mat; j++){
                drawImage(i*TAILLE_CASE_PXL , j*TAILLE_CASE_PXL , "herbe", TAILLE_CASE_PXL, TAILLE_CASE_PXL);
                if((i == 0) || (j ==  0) || (j == hauteur_mat-1) || (i == longeur_mat-1)){
                    drawImage(i*TAILLE_CASE_PXL , j*TAILLE_CASE_PXL , "buisson", TAILLE_CASE_PXL, TAILLE_CASE_PXL);
                }
            }
    
    */
    //lecture_fichier_map("map2.txt",map_int);
    case_t map_info[Y][X];
    int map_int[Y][X];
    char nom_fichier[20];
    int i,j;
    lecture_fichier_map("map2.txt", map_int);
    for(i = 0; i<Y;i++){
        for(j = 0; j<X;j++){
            printf("%i ", map_int[i][j]);
        }
        printf("\n");
    }
    mise_struct_map(map_info,map_int);
    printf("\n");
    printf("\n");
    for(i = 0;i<9; i++){
        for(j = 0; j<30; j++){
            drawImage(i*TAILLE_CASE_PXL , j*TAILLE_CASE_PXL , map_info[i][j].id, TAILLE_CASE_PXL, TAILLE_CASE_PXL);
            printf(" %s ",map_info[i][j].id);
        }
        printf("\n");
    }
    printf("\n");
    //drawImage(TAILLE_CASE_PXL*10 , TAILLE_CASE_PXL*5 , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
	//placer_pers(mat,5,10,&joueur);//probleme
    //afficher_mat(mat);

}




void start(){
    //SDL_RenderClear(renderer);
    //fond_blanc();
    int touche=-1;
    int cpt=0;
    int running = 1;
  	//init_mat(mat);
	//contour_mat(mat);
    //afficher_mat(mat);
    //init_player(&joueur);
    //placer_pers(mat,5,10,&joueur);
    map();
    faire_rendu();
    while(running == 1){  
        touche=touche_detecter();
        if(touche != 0){
            map();
            if(touche == 1){
                drawImage(TAILLE_CASE_PXL*15 , TAILLE_CASE_PXL*7 , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL ); 
                faire_rendu();

            }
            if(touche == 2){
                drawImage(TAILLE_CASE_PXL*15 , TAILLE_CASE_PXL*8 , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
            if(touche == 3){
                drawImage(TAILLE_CASE_PXL*16, TAILLE_CASE_PXL*8 , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
            if(touche == 4){
                drawImage(TAILLE_CASE_PXL*14 , TAILLE_CASE_PXL*8 , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
            if(touche == 5){
                running=0;
            }
            
            

        }        

    }
    //SDL_RenderClear(renderer);
    Menu();



}