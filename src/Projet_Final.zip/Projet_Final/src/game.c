#include "../include/gestion_deplacement.h"


void deplacement_bas(){

}

void deplacement_haut(){
    
}
void deplacement_gauche(){
    
}
void deplacement_droite(){
    
}