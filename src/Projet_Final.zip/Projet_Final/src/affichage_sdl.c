#include "../include/affichage_sdl.h"
#include "../include/fonction_sdl.h"
#include <SDL2/SDL.h>



int afficher_menu(char menu[4][30]){
  for(int i = 0, y=200; i<4; i++, y+=150){
    drawImage( 700, y, "button.png", 475, 130);
    drawText(900, y+45, menu[i], 25, 12);
  }
  faire_rendu();
  SDL_Event event;
  int running = -1;
  int mouse_x=0, mouse_y=0;
  SDL_GetMouseState(&mouse_x, &mouse_y);
  while(running == -1){
    if (SDL_WaitEvent(&event) != 0) {
      switch(event.type){
        case SDL_QUIT: running = 0; break;
        case SDL_MOUSEBUTTONDOWN:
          SDL_GetMouseState(&mouse_x, &mouse_y);
          if((mouse_x >= 700 && mouse_x <=1200) && (mouse_y >= 150 && mouse_y <=250)){
            running = 0; break;
          }
          if((mouse_x >= 700 && mouse_x <=1200) && (mouse_y >= 350 && mouse_y <=450)){
            running = 1;break;
          }
          if((mouse_x >= 700 && mouse_x <=1200) && (mouse_y >= 550 && mouse_y <=650)){
            running = 2; break;
          }
          if((mouse_x >= 700 && mouse_x <=1200) && (mouse_y >= 750 && mouse_y <=850)){
            running=3; break;
          }
      }
    }
  }
  return running;
}

  /*while(running==-1) {
      if (SDL_WaitEvent(&e) != 0) {
        switch(e.type) {
          case SDL_QUIT: running = 0;
          break;
          case SDL_MOUSEBUTTONDOWN:
          {
            int mouse_x=0, mouse_y=0;
            SDL_GetMouseState(&mouse_x, &mouse_y);
            //si on est dans la largeur du menu
            if(mouse_x>700 && mouse_x<1170){
              //si on est à la hauteur d'une case du sélecteur
                //int pos = mouse_y-100;
                //int i=1;
                for(int j=100; j<pos+150 ;i++, j+=150){
                  if(pos >= j && pos <= j+150) break;
                }
                for(mouse_y > 100 && mouse_y < 900){
                  //if() break;
                  break;
                }
                switch(i){
                  case 1: running = 0; break; //nouvelle partie
                  case 2: running = 1;break; //charger partie
                  case 3: running = 2; break; //options
                  case 4: running=3; break; //quitter jeu
                }
              }
            }
          break;
      }
    }
  }

  */