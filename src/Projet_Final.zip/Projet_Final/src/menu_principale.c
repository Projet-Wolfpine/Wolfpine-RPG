#include "../include/affichage_sdl.h"
#include "../include/fonction_sdl.h"
//#include "../include/game.h"

void showMenu(){
	//fond_blanc();
	SDL_DisplayMode dm;
	int largeur =dm.w;
	int running; //la variable qui gère le choix du menu
	char list[4][30] = { "Nouvelle partie", "Charger une Sauvegarde", "Options", "Quitter" };
	afficher_image_menu("images/menu.bmp");
	SDL_Delay(300);// si pas de delay l'image peux l'image du menu marche pas
    char * text;
    text = "P r o j e t - W O L F P I N E";
    drawText(largeur-1125, 40, text, 25, 12);
    faire_rendu();

    running = afficher_menu(list);
	if(running==0){
        fond_blanc();
		//start_game();
        SDL_Delay(1000);
	}
	if(running==1){
		fond_rouge();
		SDL_Delay(1000);
		
	}
	if(running==2){
		fond_vert();
		SDL_Delay(1000);
	}
	if(running==3){
		fond_bleu();
		SDL_Delay(1000);
		//quitter_affichage();
	}
}