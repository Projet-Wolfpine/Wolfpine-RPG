int deplacement_bas();
int deplacement_haut();
int deplacement_gauche();
int deplacement_droite();