#include "../include/gestion_deplacement.h"
#include "../include/fonction_sdl.h"
#include <SDL2/SDL.h>



int touche_deplacement(){
    const Uint8 *state = SDL_GetKeyboardState(NULL);
    
    

}