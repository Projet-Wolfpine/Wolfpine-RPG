#include "../include/affichage_sdl.h"
#include "../include/fonction_sdl.h"
#include "../include/gestion_deplacement.h"
//#include "../include/game.h"
TTF_Font *police;

void showMenu(){
	//fond_blanc();
	int largeur = dm.w;
	int running; //la variable qui gère le choix du menu
	char list[4][30] = { "Nouvelle partie", "Charger une Sauvegarde", "Options", "Quitter" };
	afficher_image_menu("images/menu.bmp");
	SDL_Delay(300);// si pas de delay l'image peux l'image du menu marche pas
    char * text;
    text = "P r o j e t - W O L F P I N E";
	int w;
	TTF_SizeText(police,text,&w,NULL);
	printf("largeur : %d\n",largeur);
	printf("taille w: %d\n",w);
    drawText((largeur-w)/2, 40, text, 45, 15);
    faire_rendu();

    running = afficher_menu(list);
	if(running==0){
		fond_blanc();

	}
	if(running==1){
		fond_rouge();
		SDL_Delay(1000);
		
	}
	if(running==2){
		fond_vert();
		SDL_Delay(1000);
	}
	if(running==3){
		fond_bleu();
		SDL_Delay(1000);
		//quitter_affichage();
	}
}