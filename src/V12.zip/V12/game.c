#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "fonction_sdl.h"
#include "gestion_deplacement_sdl.h"
#include "menu_principal.h"
#include "deplacement.h"
#include "game.h"
#include "creation_map.h"
#include "combat.h"

#define TAILLE_CASE_PXL 64

/*
perso_t joueur;
joueur = init_player();
*/
char * nom_map="map1.txt";


//joueur = malloc(sizeof(perso_t));

void start(){
    int y=10,x=10;
    SDL_RenderClear(renderer);
    int touche=-1;
    int running = 1;
    case_t mat[Y][X];
    perso_t joueur;
    joueur = init_player();
  	init_mat(mat);
	contour_mat(mat);
    afficher_mat(mat);
    placer_pers(mat,x,y,&joueur);
    afficher_mat(mat);
    afficher_map(nom_map,64);
    faire_rendu();
    while(running == 1){
        touche=touche_detecter();
        if(touche != 0){
            afficher_map(nom_map,64);
        
            if(touche == 1 && dessus(mat,&joueur)){
                //nom_map="map2.txt";
                y--;
                //afficher_mat(mat);
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL ); 
                faire_rendu();

            }
            if(touche == 2 && dessous(mat,&joueur)){
                //nom_map="map3.txt";
                y++;
                //afficher_mat(mat);
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
                
            }
            if(touche == 3 && droite(mat,&joueur)){
                x++;
                //afficher_mat(mat);
                drawImage(TAILLE_CASE_PXL*x, TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
                
            }
            if(touche == 4 && gauche(mat,&joueur)){
                x--;
                //afficher_mat(mat);
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
                
            }
            if(touche == 5){
                running=0;
            }
            if((x == 4 && y == 3) && !strcmp(nom_map,"map1.txt") ){
                nom_map="map_test.txt";
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
             if((x == 4 && y == 3) && !strcmp(nom_map,"map_test.txt") ){
                nom_map="map1.txt";
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
            
            if(x == 10 && y == 10){
            	monstre_t monstre;
            	init_monster(&monstre, "Wolfy", 5, 5 ,5);
   	
            	drawImage(500, 50 , "combat.png", 1920/2, 1080/2);
            	drawText(900,75,monstre.name,25,25);
            	//drawText(1080,75,monstre.hp,25,25);
            	
            	faire_rendu();
            	
 							
            	combat(&joueur,&monstre);
            }

        }      

    }
    Menu();
}
