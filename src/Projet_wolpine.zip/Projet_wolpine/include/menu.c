#include "ref.h"
#include "affichage_sdl.h"
#include "fonction_sdl.h"
#include "game.h"
#include "menu.h"


void afficher_menu(){
	fond_blanc();
	int lancer; /*choix du menu*/
	char list[4][30] = { "Commencer une partie", "Charger une partie", "Options", "Quitter" };
	SDL_Log("je suis la sdl 1");
	lancer = afficher_du_menu(list);
	if(lancer==0){
		/*FONCTION INIT INVENTAIRE,COMBAT (A FAIRE)*/
		commencer_game(0.0,0.0);//determiner coordonnées spawn du personnage !

	}
	if(lancer==1){
        sauvegarde("sauvegarde.txt");
    }
	if(lancer==2){
        afficher_option();
    }
	if(lancer==3){
		quitter_game();
	}
}

void afficher_option(){
    exit(1);
}

void sauvegarde(char * fichier){
	exit(1);
}