#include "ref.h"
#include "fonction_sdl.h"


SDL_Renderer*renderer;
SDL_Texture * images[50]; 
TTF_Font *font;
int nb_images=0;
char ** noms;
SDL_Color couleurDoree = {204, 154, 0};
/*
void chargement_image(){
	printf("Chargement des images\n");
	DIR *d;
	struct dirent *dir;

	d = opendir("../image/");
	while ((dir = readdir(d)) != NULL) nb_images++;
	closedir(d);

	noms = malloc(sizeof(char*)*nb_images);

	d = opendir("../image/");
	for (int i=0;(dir = readdir(d)) != NULL; i++){
		noms[i] = malloc(sizeof(char)*strlen(dir->d_name)+1);
		strcpy(noms[i], dir->d_name);
	}
	closedir(d);
	for(int i=0; i<nb_images; i++){
		char nom[50] = "../image/";
		strcat(nom, noms[i]);
		images[i] = IMG_LoadTexture(renderer, nom);
		if(i==22){
			printf("%s\n", nom);
		}
	}
	printf("Les images sont chargées: %d\n", nb_images);
}
*/

void unloadImages(){
	for(int i=0; i<nb_images; i++){
		SDL_DestroyTexture(images[i]);
	}
}

void faire_rendu(){
	SDL_RenderPresent(renderer);
}

void fond_blanc(){
	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
	SDL_RenderClear(renderer);
	faire_rendu();
}

void quitter_game(){
	unloadImages();
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(fenetre);
	TTF_CloseFont(font);
	TTF_Quit();
	IMG_Quit();
	SDL_Quit();
}

void drawText (int x, int y, char * string, int h, int w){
	SDL_Surface *texte = TTF_RenderUTF8_Blended(font, string, couleurDoree);
	SDL_Texture *texte_tex = SDL_CreateTextureFromSurface(renderer, texte);
	SDL_Rect txtDestRect;
	txtDestRect.x = x;
	txtDestRect.y = y;
	txtDestRect.h = h;
	txtDestRect.w = w*strlen(string);
    SDL_FreeSurface(texte); 
	SDL_RenderCopy(renderer, texte_tex, NULL, &txtDestRect);
	SDL_DestroyTexture(texte_tex);
	
}

void drawImage (int x, int y, char * nom, int w, int h){
	/*
	// x et y les coordonnées,
	SDL_Rect imgDestRect;
	imgDestRect.x = x;
	imgDestRect.y = y;
	imgDestRect.w = w;
	imgDestRect.h = h;
  	char nom2[50];
  	sprintf(nom2, "%s", nom);
  	if(!strstr(nom2, ".png")){
   		strcat(nom2, ".png");
  	}
	int i;
	SDL_Log("je suis la sdl 85");

	//ici on recherche quel est l'indice de l'image qu'on veux afficher
	for(i=0; strcmp(noms[i], nom2)!=0 && i<nb_images; i++);	
	SDL_Log("je suis la sdl 86");

	//on l'affiche ensuite
	SDL_RenderCopy(renderer, images[i], NULL, &imgDestRect);
	//SDL_DestroyTexture(image_tex);  	
	
*/
}

void init_affichage(){
	if (SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO) != 0) {
        SDL_Log("Impossible d'initialiser SDL: %s", SDL_GetError());
        exit(1);
    }
	else{
	SDL_Log("SDL initialiser ");
	}
	/* Initialisation TTF */
	if (TTF_Init() != 0) {
        SDL_Log("Impossible d'initialiser TTF: %s", SDL_GetError());
        exit(1);
    }
	else{
	SDL_Log("TTF initialiser ");
	}
	SDL_DisplayMode ecran;
	SDL_GetCurrentDisplayMode(0, &ecran);
	font = TTF_OpenFont("Halo3.ttf", 25);
	Hauteur_ecran = ecran.h;
	Largeur_ecran = ecran.w;
	/* Création de la fenêtre */
	fenetre = SDL_CreateWindow("Projet Wolfpine",SDL_WINDOWPOS_UNDEFINED,
													SDL_WINDOWPOS_UNDEFINED,
													Largeur_ecran,
													Hauteur_ecran,
													SDL_WINDOW_SHOWN);

	renderer=SDL_CreateRenderer(fenetre, -1, SDL_RENDERER_ACCELERATED);
	SDL_SetWindowFullscreen(fenetre, SDL_WINDOW_FULLSCREEN);
	//chargement_image();
}