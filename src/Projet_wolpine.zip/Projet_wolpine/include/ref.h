#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>

#define QUITTER 111

int jeu_ouvert;

typedef enum booleen_s {FALSE, TRUE} booleen_t ;