#include "ref.h"
#include "menu.h"
#include "fonction_sdl.h"


void commencer_game(float x, float y){
    jeu_ouvert = TRUE;
    faire_rendu();
    while((jeu_ouvert)!=QUITTER){
        //afficher_Map( x, y);
    }

}

