#include "ref.h"
#include "fonction_sdl.h"

int afficher_du_menu(char menu[4][30]){

 
  fond_blanc();
   //ne fonctionne pas
  /*for(int i = 0, y=100; i<4; i++, y+=150){
    drawImage( 500, y, "button.png", 475, 130);
    drawText(525, y+25, menu[i], 25, 12);
  }*/


  faire_rendu();
  SDL_Event e;
  int lancer = -1;
  while(lancer==-1) {
      if (SDL_WaitEvent(&e) != 0) {
        switch(e.type) {
          case SDL_QUIT: lancer = 0;break;
          case SDL_MOUSEBUTTONDOWN:
          {
            int mouse_x, mouse_y;
            SDL_GetMouseState(&mouse_x, &mouse_y);
            if(mouse_x>500 && mouse_x<975){
                int pos = mouse_y-100;
                int i=1;
                for(int j=0; j<pos+150 ;i++, j+=150){
                  if(pos >= j && pos <= j+150) break;
                }
                switch(i){
                  case 1: lancer = 0; break; //nouvelle partie
                  case 2: lancer = 1; break; //charger une sauvegarde
                  case 3: lancer = 2; break; //options
                  case 4: lancer = 3;   break; //fermer le  jeu
                }
              }

            }
          break;
      }
    }
  }
  return lancer;
}


void afficher_Map(float x, float y){


}