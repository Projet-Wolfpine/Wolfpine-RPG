int afficher_du_menu(char menu[4][30]);
void afficher_Map(float, float);