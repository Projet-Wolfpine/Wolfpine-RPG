int Hauteur_ecran;
int Largeur_ecran;
void * fenetre;


void unloadImages();
void faire_rendu();
void fond_blanc();
void quitter_game();
void drawText (int x, int y, char * string, int h, int w);
void drawImage (int x, int y, char * nom, int w, int h);
void init_affichage();