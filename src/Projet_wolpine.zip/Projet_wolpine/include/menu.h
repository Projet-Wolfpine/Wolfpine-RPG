void afficher_menu();
void afficher_option();
void sauvegarde(char * fichier);