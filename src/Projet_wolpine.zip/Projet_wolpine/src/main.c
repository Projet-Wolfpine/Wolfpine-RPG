#include "../include/ref.h"
#include "../include/menu.h"
#include "../include/fonction_sdl.h"


int main(int argc, char** argv){
	printf("test");
	init_affichage();
	printf("test");
	afficher_menu();

	return 0;
}