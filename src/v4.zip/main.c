#include "include/menu_principal.h"
#include "include/commun.h"
#include "include/fonction_sdl.h"

int main(int argc, char** argv){
	init_affichage();
    Menu();
    return 0;
}