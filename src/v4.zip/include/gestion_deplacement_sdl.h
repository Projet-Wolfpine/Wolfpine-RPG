#include <SDL2/SDL.h>

SDL_Event events;

int touche_detecter();
int touche_haut();
int touche_bas();
int touche_gauche();
int touche_droite();
int esc();