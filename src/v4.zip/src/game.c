#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "../include/fonction_sdl.h"
#include "../include/gestion_deplacement_sdl.h"
#include "../include/menu_principal.h"


void start(){
    int touche=-1;
    int cpt=0;
    
    int running = 1;
    while(running == 1){
        cpt++;
        touche=touche_detecter();
        printf("%d\n",touche);
        
        if(touche != 0){
            //afficher_Map();
            if(touche == 1){
                fond_rouge();
                touche=-1;

            }
            if(touche == 2){
                fond_vert();
                touche=-1;

            }
            if(touche == 5){
                running=0;
            }
            faire_rendu();
            

        }
        if(cpt == 15){
            running=0;
        }


        

    }
    //SDL_RenderClear(renderer);
    Menu();



}