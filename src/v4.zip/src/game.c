#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "../include/fonction_sdl.h"
#include "../include/gestion_deplacement_sdl.h"
#include "../include/menu_principal.h"


void start(){
    
    
    int running = 1;
    while(running == 1){
        if(esc()){
            running=0;
        }
        if(touche_detecter()){
            //afficher_Map();
            faire_rendu();

        }

        

    }

    Menu();



}