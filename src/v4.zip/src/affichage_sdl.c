#include "../include/affichage_sdl.h"
#include "../include/fonction_sdl.h"
#include <SDL2/SDL.h>


int afficher_menu(char menu[4][30]){
  //int largeur = dm.w;
  for(int i = 0, y=200; i<4; i++, y+=150){
    drawImage( 700, y, "button.png", 475, 130);
    drawText(800, y+45, menu[i], 25, 12);
  }
  faire_rendu();
  SDL_Event event;
  int running = -1;
  int mouse_x=0, mouse_y=0;
  SDL_GetMouseState(&mouse_x, &mouse_y);
  while(running == -1){
    if (SDL_WaitEvent(&event) != 0) {
      switch(event.type){
        case SDL_QUIT: running = 0; break;
        case SDL_MOUSEBUTTONDOWN:
          SDL_GetMouseState(&mouse_x, &mouse_y);
          if((mouse_x >= 700 && mouse_x <=1175) && (mouse_y >= 200 && mouse_y <=330)){// ecart de 20 entre chaque cases et une case = 130
            running = 0; break;
          }
          if((mouse_x >= 700 && mouse_x <=1175) && (mouse_y >= 350 && mouse_y <=480)){
            running = 1;break;
          }
          if((mouse_x >= 700 && mouse_x <=1175) && (mouse_y >= 500 && mouse_y <=630)){
            running = 2; break;
          }
          if((mouse_x >= 700 && mouse_x <=1175) && (mouse_y >= 650 && mouse_y <=780)){
            running=3; break;
          }
      }
    }
  }
  return running;
}
