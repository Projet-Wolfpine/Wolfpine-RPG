#include "../include/gestion_deplacement_sdl.h"
#include "../include/fonction_sdl.h"
#include <SDL2/SDL.h>

SDL_Event event;

int touche_detecter(){ 
    int touche=0;
    if(SDL_WaitEvent(&event) != 0){
        switch(event.type){
            case SDL_KEYDOWN:
                SDL_GetKeyboardState(&touche);
                if((touche == SDLK_w) || (touche == SDLK_UP)){ // touche haut (W) en qwerty
                    touche = 1; break;
                }
                if((touche == SDLK_s) || (touche == SDLK_DOWN)){ // touche bas (S) en qwerty
                    touche = 2; break;
                }
                if((touche == SDLK_d) || (touche == SDLK_RIGHT)){ // touche droite (D) en qwerty
                    touche = 3; break;
                }
                if((touche == SDLK_a) || (touche == SDLK_LEFT)){ // touche gauche (A) en qwerty
                    touche = 4; break;
                }
                if(touche == SDLK_ESCAPE){ // touche escap 
                    touche = 5; break;
                }
        }
    }
    return touche;
}
