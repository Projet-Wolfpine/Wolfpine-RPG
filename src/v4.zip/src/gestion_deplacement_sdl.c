#include "../include/gestion_deplacement_sdl.h"
#include "../include/fonction_sdl.h"
#include <SDL2/SDL.h>

int touche_detecter(){
    return 0;
}


int touche_haut(){
    /*if(){
        return 1

    }*/
    return 0;
    

}

int touche_bas(){
    /*if(){

        return 1

    }*/
    return 0;
    
    
}
int touche_gauche(){
    /*if(){

        return 1

    }*/
    return 0;
    
    
}
int touche_droite(){
    /*if(){

        return 1

    }*/
    return 0;
    
}

int esc(){
    /*if(){

        return 1

    }*/
    return 0;


}