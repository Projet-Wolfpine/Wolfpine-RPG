#include "../include/commun.h"

const err_t OK_state = 1;
const err_t KO_state = 0;






