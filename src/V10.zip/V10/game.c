#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include "fonction_sdl.h"
#include "gestion_deplacement_sdl.h"
#include "menu_principal.h"
#include "deplacement.h"
#include "game.h"
#include "creation_map.h"
#include "combat.h"

#define TAILLE_CASE_PXL 64

/*
perso_t joueur;
joueur = init_player();
*/
char * nom_map="map1.txt";

//joueur = malloc(sizeof(perso_t));

void start(){
    int y=10,x=10;
    SDL_RenderClear(renderer);
    int touche=-1;
    int running = 1;
    case_t mat[Y][X];
    perso_t joueur;
    joueur = init_player();
  	init_mat(mat);
	contour_mat(mat);
    afficher_mat(mat);
    placer_pers(mat,x,y,&joueur);
    afficher_mat(mat);
    afficher_map(nom_map,64);
    faire_rendu();
    while(running == 1){
        touche=touche_detecter();
        if(touche != 0){
            afficher_map(nom_map,64);
        
            if(touche == 1){
                //nom_map="map2.txt";
                y--;
                aller_dessus(mat,&joueur);
                afficher_mat(mat);
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL ); 
                faire_rendu();

            }
            if(touche == 2){
                //nom_map="map3.txt";
                y++;
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
                
            }
            if(touche == 3){
                x++;
                drawImage(TAILLE_CASE_PXL*x, TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
                
            }
            if(touche == 4){
                x--;
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
                
            }
            if(touche == 5){
                running=0;
            }
            if((x == 4 && y == 3) && !strcmp(nom_map,"map1.txt") ){
                nom_map="map_test.txt";
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
             if((x == 4 && y == 3) && !strcmp(nom_map,"map_test.txt") ){
                nom_map="map1.txt";
                drawImage(TAILLE_CASE_PXL*x , TAILLE_CASE_PXL*y , "perso.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
                faire_rendu();
            }
            
            

        }      

    }
    Menu();
}