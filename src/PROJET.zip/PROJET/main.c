#include "menu_principale.h"
#include "commun.h"
#include "fonction_sdl.h"
#include "deplacement.h"

int main(int argc, char** argv){
	init_affichage();
    showMenu();
    return 0;
}
