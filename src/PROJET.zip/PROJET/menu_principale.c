#include "affichage_sdl.h"
#include "fonction_sdl.h"
#include <SDL2/SDL_image.h>
#include <SDL2/SDL.h>
#include "deplacement.h"
//#include "../include/game.h"
TTF_Font *police;
SDL_DisplayMode dm;
#define TAILLE_CASE_PXL 64
//#define TAILLE_CASE_PXL2 63


void map(){
	fond_blanc();
	int longeur = 1920;
	int hauteur = 1080;
	int longeur_mat = longeur/TAILLE_CASE_PXL;
	int hauteur_mat = hauteur/TAILLE_CASE_PXL;
	for(int i = 0;i<longeur_mat; i++)
			for(int j = 0; j<hauteur_mat; j++)
				drawImage(i*TAILLE_CASE_PXL , j*TAILLE_CASE_PXL , "herbe.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );

}

void showMenu(){
	//fond_blanc();
	int longeur2 = dm.w;
	int hauteur2 = dm.h;
	int longeur = 1920;
	int hauteur = 1080;
	int running; //la variable qui gère le choix du menu
	char list[4][30] = { "Nouvelle partie", "Charger une Sauvegarde", "Options", "Quitter" };
	afficher_image_menu("images/menu.bmp");
	SDL_Delay(400);// si pas de delay l'image peux l'image du menu marche pas
    char * text;
    text = "P r o j e t - W O L F P I N E";
	int w;
	TTF_SizeText(police,text,&w,NULL);
	printf("longeur : %d\n",longeur2);
	printf("hauteur w: %d\n",hauteur2);
	//printf("longeur : %d\n",longeur);
	//printf("hauteur w: %d\n",hauteur);
    drawText((longeur-w)/2, 40, text, 45, 15);
    //faire_rendu();

    running = afficher_menu(list);
	if(running==0){
		int longeur_mat = longeur/TAILLE_CASE_PXL;
		int hauteur_mat = hauteur/TAILLE_CASE_PXL;

		//Test de la création matrice terminal
		case_t mat[Y][X];
   		perso_t *joueur;
  		init_mat(mat);
		contour_mat(mat);
		placer_pers(mat,1,30,joueur);



		map();

		//affichage personnage 

		drawImage(1*TAILLE_CASE_PXL, 30*TAILLE_CASE_PXL , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );//probleme au niveau de l'affichage surement du à un soucis de Y X et cette fonction est en X Y
		faire_rendu();

		SDL_Delay(5000);
	}
	if(running==1){
		fond_rouge();
		SDL_Delay(1000);
		
	}
	if(running==2){
		fond_vert();
		SDL_Delay(1000);
	}
	if(running==3){
		//quitter_affichage();
	}
}


/*
	drawImage(500, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(550, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(600, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(625, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(650, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(700, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(725, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();
		SDL_Delay(500);
		map();
		drawImage(750, 500 , "cadre.png", TAILLE_CASE_PXL, TAILLE_CASE_PXL );
		faire_rendu();

		*/