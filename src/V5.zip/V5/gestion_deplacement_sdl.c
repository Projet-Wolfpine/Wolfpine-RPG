#include "gestion_deplacement_sdl.h"
#include "fonction_sdl.h"
#include <SDL2/SDL.h>

SDL_Event event;

int touche_detecter(){ 
    int touchev1=0;
    int touche=0;
    if(SDL_WaitEvent(&event) != 0){
        switch(event.type){
            case SDL_KEYDOWN:
                if((events.key.keysym.sym == SDL_SCANCODE_W) || (events.key.keysym.sym == SDLK_UP)){ // touche haut (W) en qwerty
                    printf("je suis la ! \n");
                    touche = 1; break;
                }
                if((events.key.keysym.sym == SDLK_s) || (events.key.keysym.sym == SDLK_DOWN)){ // touche bas (S) en qwerty
                    touche = 2; break;
                }
                if((events.key.keysym.sym == SDLK_d) || (events.key.keysym.sym == SDLK_RIGHT)){ // touche droite (D) en qwerty
                    touche = 3; break;
                }
                if((events.key.keysym.sym == SDLK_a) || (events.key.keysym.sym == SDLK_LEFT)){ // touche gauche (A) en qwerty
                    touche = 4; break;
                }
                if(events.key.keysym.sym == SDLK_ESCAPE){ // touche escap 
                    touche = 5; break;
                }
        }
    }
    printf("sdl = %d\n",touche);
    return touche;
}