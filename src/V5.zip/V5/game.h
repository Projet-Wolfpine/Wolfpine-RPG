void start();
void map();
#define TAILLE_CASE_PXL 64