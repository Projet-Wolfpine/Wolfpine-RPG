#include <SDL2/SDL.h>

SDL_Event events;

int touche_detecter();