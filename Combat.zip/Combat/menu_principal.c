#include "affichage_sdl.h"
#include "fonction_sdl.h"
#include <SDL2/SDL_image.h>
#include <SDL2/SDL.h>
#include  "game.h"


TTF_Font *police;

void Menu(){
	SDL_DisplayMode dm;
	int longeur = 1920;
	int hauteur = 1080;
	int largeur = dm.w;
	int running=-1; //la variable qui gère le choix du menu
	char list[4][30] = { "Nouvelle partie", "Charger une Sauvegarde", "Options", "Quitter" };
	running = afficher_menu(list);

	if(running==0){
		start();
	}
	if(running==1){
		fond_rouge();
		SDL_Delay(1000);
		
	}
	if(running==2){
		fond_vert();
		SDL_Delay(1000);
	}
	if(running==3){
		quitter_affichage();
	}
}
