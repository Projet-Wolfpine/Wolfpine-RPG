#ifndef _DUNGEON_H
#define _DUNGEON_H
#include "structures.h"

#define NB_SALLES 6

void init_salle()

















#endif
